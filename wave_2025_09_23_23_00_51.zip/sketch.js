function setup() {
  createCanvas(600, 600);
  angleMode(DEGREES)
}

function draw() {
  background(220);
  
  let stepSize = 20
  for(let x = stepSize/2; x < width; x+=stepSize) {
    
    let y = map(sin(frameCount + x), -1, 1, height/4, 3*height/4)
    ellipse(x, y, stepSize/2)
  }
}
